package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView

class DropdownActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dropdown)

        // get reference to the string array that we just created
        val pilihan = resources.getStringArray(R.array.Dari)
        // create an array adapter and pass the required parameter
        // in our case pass the context, drop down layout , and array.
        val arrayAdapter = ArrayAdapter(this, R.layout.dropdown_item, pilihan)
        // get reference to the autocomplete text view
        val autocompleteTV = findViewById<AutoCompleteTextView>(R.id.autoCompleteTextView)
        // set adapter to the autocomplete tv to the arrayAdapter
        autocompleteTV.setAdapter(arrayAdapter)

        val arrayAdapter1 = ArrayAdapter(this, R.layout.dropdown_item, pilihan)
        val autoCompleteTV1 = findViewById<AutoCompleteTextView>(R.id.autoCompleteTextView1)
        autoCompleteTV1.setAdapter(arrayAdapter1)
    }
}
